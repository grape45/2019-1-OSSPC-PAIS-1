package tetris_fix;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JPanel;

public class NormalContainer extends JPanel{
	
	private UserContainer uc;
	
	public NormalContainer() {
		this.setBounds(0, 50, 640, 620);
		this.setLayout(new GridLayout(1,2));
		this.setBackground(Color.BLACK);
		uc = new UserContainer();
		this.add(uc);
	}
}
