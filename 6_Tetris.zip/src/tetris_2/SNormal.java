package tetris_2;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

public class SNormal extends JPanel{
	BoardPanel player = new BoardPanel(50, 50, 300, 600);
	BoardPanel computer = new BoardPanel(880, 50, 300, 600);
	
	public SNormal() {
		setSize(Main.SCREEN_WIDTH, Main.SCREEN_HEIGHT);
		setVisible(true);
		setBackground(new Color(0, 0, 0, 0));
		setLayout(null); // ȭ�鿡 ��ġ�Ǵ� ��ư�̳� label�� �� �ڸ� �״�� ���� ��.
		add(player);
		add(computer);
		
	}
}
