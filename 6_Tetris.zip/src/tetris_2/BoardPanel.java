package tetris_2;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

import org.psnbtech.TileType;

public class BoardPanel extends JPanel {
	public static final int COLOR_MIN = 35;
	public static final int COLOR_MAX = 255 - COLOR_MIN;

	public static final int COL_COUNT = 10; // �������� ���� ��
	private static final int VISIBLE_ROW_COUNT = 20; // �����ǿ��� ���̴� ���� ��
	private static final int HIDDEN_ROW_COUNT = 2; // �����ǿ��� �Ⱥ��̴� ���� ��(����)
	public static final int ROW_COUNT = VISIBLE_ROW_COUNT + HIDDEN_ROW_COUNT;

	public static final int TILE_SIZE = 30; // �������� Ÿ�� ������
	public static final int SHADE_WIDTH = 10; // ������ �׸��� ��

	private static final int CENTER_X = COL_COUNT * TILE_SIZE / 2; // �������� �߾� x��ǥ
	private static final int CENTER_Y = VISIBLE_ROW_COUNT * TILE_SIZE / 2; // �������� �߾� y��ǥ

	
	private TileType[][] tiles;
	
	public BoardPanel(int x, int y, int width, int height) {
		this.tiles = new TileType[ROW_COUNT][COL_COUNT];
		
		setBounds(x, y, width, height);
		setBackground(Color.BLACK);
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		for (int x = 0; x < COL_COUNT; x++) {
			for (int y = HIDDEN_ROW_COUNT; y < ROW_COUNT; y++) {
				TileType tile = getTile(x, y);
				if (tile != null) {
					drawTile(tile, x * TILE_SIZE, (y - HIDDEN_ROW_COUNT) * TILE_SIZE, g);
				}
			}
		}
		g.setColor(Color.WHITE);
		g.drawRect(0, 0, 299, 599);
		//g.drawRect(0, 0, TILE_SIZE * COL_COUNT + 49, TILE_SIZE * VISIBLE_ROW_COUNT + 48);
		
		for(int x = 0; x < COL_COUNT; x++) {
			for(int y = 0; y < VISIBLE_ROW_COUNT; y++) {
				g.drawLine(0, y * TILE_SIZE, COL_COUNT * TILE_SIZE, y * TILE_SIZE);
				g.drawLine(x * TILE_SIZE, 0, x * TILE_SIZE, VISIBLE_ROW_COUNT * TILE_SIZE);
			}
		}
	}
	public void clear() {
		/*
		 * Loop through every tile index and set it's value
		 * to null to clear the board.
		 */
		for(int i = 0; i < ROW_COUNT; i++) {
			for(int j = 0; j < COL_COUNT; j++) {
				tiles[i][j] = null;
			}
		}
	}
	
	public boolean isValidAndEmpty(TileType type, int x, int y, int rotation) {
		
		//Ensure the piece is in a valid column.
		if(x < -type.getLeftInset(rotation) || x + type.getDimension() - type.getRightInset(rotation) >= COL_COUNT) {
			return false;
		}
		
		//Ensure the piece is in a valid row.
		if(y < -type.getTopInset(rotation) || y + type.getDimension() - type.getBottomInset(rotation) >= ROW_COUNT) {
			return false;
		}
		
		/*
		 * Loop through every tile in the piece and see if it conflicts with an existing tile.
		 * 
		 * Note: It's fine to do this even though it allows for wrapping because we've already
		 * checked to make sure the piece is in a valid location.
		 */
		for(int col = 0; col < type.getDimension(); col++) {
			for(int row = 0; row < type.getDimension(); row++) {
				if(type.isTile(col, row, rotation) && isOccupied(x + col, y + row)) {
					return false;
				}
			}
		}
		return true;
	}
	
	public void addPiece(TileType type, int x, int y, int rotation) {
		/*
		 * Loop through every tile within the piece and add it
		 * to the board only if the boolean that represents that
		 * tile is set to true.
		 */
		for(int col = 0; col < type.getDimension(); col++) {
			for(int row = 0; row < type.getDimension(); row++) {
				if(type.isTile(col, row, rotation)) {
					setTile(col + x, row + y, type);
				}
			}
		}
	}
	
	public int checkLines() {
		int completedLines = 0;
		
		/*
		 * Here we loop through every line and check it to see if
		 * it's been cleared or not. If it has, we increment the
		 * number of completed lines and check the next row.
		 * 
		 * The checkLine function handles clearing the line and
		 * shifting the rest of the board down for us.
		 */
		for(int row = 0; row < ROW_COUNT; row++) {
			if(checkLine(row)) {
				completedLines++;
			}
		}
		return completedLines;
	}
	

	private boolean checkLine(int line) {
		/*
		 * Iterate through every column in this row. If any of them are
		 * empty, then the row is not full.
		 */
		for(int col = 0; col < COL_COUNT; col++) {
			if(!isOccupied(col, line)) {
				return false;
			}
		}
		
		/*
		 * Since the line is filled, we need to 'remove' it from the game.
		 * To do this, we simply shift every row above it down by one.
		 */
		for(int row = line - 1; row >= 0; row--) {
			for(int col = 0; col < COL_COUNT; col++) {
				setTile(col, row + 1, getTile(col, row));
			}
		}
		return true;
	}
	
	private boolean isOccupied(int x, int y) {
		return tiles[y][x] != null;
	}
	
	private TileType getTile(int x, int y) {
		return tiles[y][x];
	}
	
	private void setTile(int  x, int y, TileType type) {
		tiles[y][x] = type;
	}
	
	private void drawTile(TileType type, int x, int y, Graphics g) {
		drawTile(type.getBaseColor(), type.getLightColor(), type.getDarkColor(), x, y, g);
	}

	private void drawTile(Color base, Color light, Color dark, int x, int y, Graphics g) {

		/*
		 * Fill the entire tile with the base color.
		 */
		g.setColor(base);
		g.fillRect(x, y, TILE_SIZE, TILE_SIZE);

		/*
		 * Fill the bottom and right edges of the tile with the dark shading color.
		 */
		g.setColor(dark);
		g.fillRect(x, y + TILE_SIZE - SHADE_WIDTH, TILE_SIZE, SHADE_WIDTH);
		g.fillRect(x + TILE_SIZE - SHADE_WIDTH, y, SHADE_WIDTH, TILE_SIZE);

		/*
		 * Fill the top and left edges with the light shading. We draw a single line for
		 * each row or column rather than a rectangle so that we can draw a nice looking
		 * diagonal where the light and dark shading meet.
		 */
		g.setColor(light);
		for (int i = 0; i < SHADE_WIDTH; i++) {
			g.drawLine(x, y + i, x + TILE_SIZE - i - 1, y + i);
			g.drawLine(x + i, y, x + i, y + TILE_SIZE - i - 1);
		}
	}
}
