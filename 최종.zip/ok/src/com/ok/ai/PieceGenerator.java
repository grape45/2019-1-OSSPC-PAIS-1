package com.ok.ai;
/*

This program was written by Jacob Jackson. You may modify,
copy, or redistribute it in any way you wish, but you must
provide credit to me if you use it in your own program.

*/

public interface PieceGenerator
{
	public int nextPiece();
	public void newGame();
}
